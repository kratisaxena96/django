from django.urls import path
from . import views

urlpatterns = [
    path("",views.index),  #localhost/users/
    path("home/",views.home),  #localhost/users/home
    path("signin/",views.login),  #localhost/users/signin --> /users/signin
    path("signup/",views.signup),
    path("aftersignup/",views.aftersignup),
    path("afterlogin/",views.afterlogin.as_view()),
    path("logout/",views.logout),
    path("forgot/",views.forgot),
    path("getotp/",views.getotp),
    path("checkotp/",views.checkotp)
]