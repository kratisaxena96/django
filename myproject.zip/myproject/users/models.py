from django.db import models

# Create your models here.
class Adduser(models.Model):
    fullname = models.CharField(max_length=100)
    email = models.EmailField(max_length=200,unique=True)
    password = models.CharField(max_length=500)
    pic = models.ImageField()
    #upload_to="static/images"

    def __str__(self):
        return f"{self.email}"


#pip install mysql-client
#migration
#models.py --> change --> migrations
#python manage.py makemigrations --> create new file --> 0001
#python manage.py sqlmigrate users 0001 
#python manage.py migrate --> it will migrate all your tables into the database
#python manage.py createsuperuser 
#username --> simrangrover
#password --> adminadmin
#localhost/admin --> link for admin panel
#django.admin
#python manage.py shell --> for django shell