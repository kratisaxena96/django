from django.shortcuts import render
from django.http import HttpResponse
from .forms import Blog
from django.views import View
from .models import Addblog
from users.models import Adduser
from rest_framework.views import APIView, Response
from .serializers import Addblogserializer
# Create your views here.

def index(request):
    return HttpResponse("<h1 style='color:red'>Welcome to my blog app</h1>")

def addblog(request):
    form = Blog()
    return render(request,"blogadd.html",{'form':form})

class addpost(View):
    def get(self,request):
        error = "NO such request handled"
        form = Blog()
        return render(request,"blogadd.html",{'form':form,'error':error})
    
    def post(self,request):
        form = Blog(request.POST)    #request.POST.get("name")
        if form.is_valid():
            title = form.cleaned_data['title']
            post = form.cleaned_data['post']
            user = Adduser.objects.get(email=request.session.get("email"))
            Addblog.objects.create(title=title,post=post,user=user)
            error = "Blog Added"
            return render(request,"afterlogin.html",{'error':error})
        else:
            error = "Invalid form"
            form = Blog()
            return render(request,"blogadd.html",{'form':form,'error':error})

def myblog(request):
    if request.method == "GET":
        user =Adduser.objects.get(email=request.session.get("email"))
        blogs = Addblog.objects.filter(user=user.id)
        values = []
        for i in blogs:
            d = {
                "title": i.title,
                "post" : i.post,
                "user" : i.user.fullname,
                "date" : i.date
            }
            values.append(d)
        return render(request,"userblogs.html",{'blogs':values})
    else:
        error = "No such method handled"
        return render(request,"afterlogin.html",{'error':error})

def allblogs(request):
    blogs = Addblog.objects.all()[:10]
    values = []
    for i in blogs:
        d = {
                "title": i.title,
                "post" : i.post,
                "user" : i.user.fullname,
                "date" : i.date
        }
        values.append(d)
    return render(request,"userblogs.html",{'blogs':values})

#form,model --> categories --> education, entertainment, 
#pip install djangorestframework
#python string/dict/list --> json object

class showapi(APIView):
    def get(self,request):
        data = Addblog.objects.all()
        blogs = Addblogserializer(data,many=True)
        return Response(blogs.data)
    
    def post(self,request):
        pass