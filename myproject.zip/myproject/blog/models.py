from django.db import models
from users.models import Adduser
from datetime import datetime

# Create your models here.
class Addblog(models.Model):
    title = models.CharField(max_length=200)
    post = models.TextField(max_length=2000)
    user = models.ForeignKey(to=Adduser,on_delete=models.CASCADE)
    date = models.DateField(default=datetime.now())

    def __str__(self):
        return f"{self.user}"
#foreign key(sid) references Adduser(sid)