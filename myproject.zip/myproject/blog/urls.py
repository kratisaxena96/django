from django.urls import path
from . import views

urlpatterns = [
    path("",views.index),  #"" --> localhost/blog/
    path("addblog/",views.addblog),
    path("addpost/",views.addpost.as_view()),
    path("myblog/",views.myblog),
    path("allblogs/",views.allblogs),
    path("api/",views.showapi.as_view())
]